# Liquid glass navbar: React version

The A8 Tiger Fitness site is plain HTML, CSS and JavaScript, so it uses
`liquid-nav.js` (a plain-JavaScript port of this component) and needs no build step.

This folder is for moving the site to a React project later.

## Setting up a React project (Next.js + TypeScript + Tailwind + shadcn)

```bash
npx create-next-app@latest a8-tiger-fitness --typescript --tailwind --app
cd a8-tiger-fitness
npx shadcn@latest init        # creates components/ui and the "@/..." import alias
```

Then copy `components/ui/liquid-glass-navbar.tsx` into the project's `components/ui/`.
The component has no dependencies other than React. It has to live in `components/ui`
because shadcn tools, and the demo's import path `@/components/ui/liquid-glass-navbar`,
expect it there.

## Usage

```tsx
import { LiquidNavbar, NimbusIcons } from "@/components/ui/liquid-glass-navbar"

<LiquidNavbar
  tone="dark"
  items={[
    { label: "Home", href: "#home", icon: NimbusIcons.home, fx: "glow" },
    { label: "Contact", href: "#contact", icon: NimbusIcons.plane, fx: "plane" },
  ]}
/>
```

Props: `items`, `defaultActive`, `active` (controlled), `onChange`,
`tone` ("light" | "dark"), `compact` (icons only), `sound`, `className`, `style`.

---

## Polaroid line carousel (gallery)

File: `components/ui/polaroid-line-carousel.tsx`. No extra packages are needed beyond React.

The plain-HTML site uses the same component rewritten in `../polaroid-carousel.js`, in the gallery section with the gym photos.

In a React/Next.js project, copy your gym photos into `public/gallery/` and use it like this:

```tsx
"use client"
import PolaroidLineCarousel from "@/components/ui/polaroid-line-carousel"

export default function GymGallery() {
  return (
    <PolaroidLineCarousel
      height="clamp(440px, 46vw, 600px)"
      cardWidth={270}
      sag={40}
      string="#ffe600"
      background="#0a0a0a"
      ink="#ffffff"
      slides={[
        { image: "/gallery/reception.webp", title: "Reception", caption: "Your first step into A8 Tiger Fitness." },
        { image: "/gallery/cardio.webp", title: "Cardio Zone", caption: "Treadmills, bikes and cross-trainers." },
        { image: "/gallery/turf.webp", title: "Turf Training Area", caption: "Sleds, sprints and functional work." },
        { image: "/gallery/strength.webp", title: "Strength Zone", caption: "Racks, plates and dumbbells for every lift." },
        { image: "/gallery/studio.webp", title: "Studio Room", caption: "Yoga, Zumba, spinning and group classes." },
      ]}
    />
  )
}
```

Props: `slides`, `height`, `cardWidth`, `sag`, `swing`, `autoplay` (ms, 0 = off), `string`, `background`, `ink`, `onChange`, `ariaLabel`. Slides without an `image` get a painted landscape.

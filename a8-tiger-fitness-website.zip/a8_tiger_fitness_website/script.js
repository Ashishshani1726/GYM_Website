const $ = (s, p=document) => p.querySelector(s);
const $$ = (s, p=document) => [...p.querySelectorAll(s)];
document.documentElement.classList.add('js');

// Reveal on scroll
const observer = new IntersectionObserver(entries => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      entry.target.style.transitionDelay = `${Math.min(i*60, 240)}ms`;
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: .12 });
$$('.reveal').forEach(el => observer.observe(el));

// Gallery: polaroid prints on a string (see polaroid-carousel.js)
const gallery = window.PolaroidCarousel($('#polaroidGal'), {
  slides: [
    { image: 'assets/mk/reception.webp', title: 'Reception', caption: 'Your first step into A8 Tiger Fitness.' },
    { image: 'assets/mk/cardio.webp', title: 'Cardio Zone', caption: 'Treadmills, bikes and cross-trainers.' },
    { image: 'assets/mk/turf.webp', title: 'Turf Training Area', caption: 'Sleds, sprints and functional work.' },
    { image: 'assets/mk/strength.webp', title: 'Strength Zone', caption: 'Racks, plates and dumbbells for every lift.' },
    { image: 'assets/mk/studio.webp', title: 'Studio Room', caption: 'Yoga, Zumba, spinning and group classes.' },
    { image: 'assets/gallery/reception-turf.webp', title: 'The Fitness World', caption: 'Front desk looking out over the turf.' },
    { image: 'assets/gallery/cardio-zone.webp', title: 'Treadmill Row', caption: 'Mirror-lit cardio along the turf.' },
    { image: 'assets/gallery/weights-area.webp', title: 'Free Weights', caption: 'Dumbbell racks and benches by the windows.' },
    { image: 'assets/gallery/cardio-corner.webp', title: 'Cardio Corner', caption: 'Stepper and cross-trainer by the window.' },
    { image: 'assets/gallery/dumbbell-bay.webp', title: 'Dumbbell Bay', caption: 'A quiet corner for focused lifting.' },
    { image: 'assets/gallery/studio-room.webp', title: 'Mirror Studio', caption: 'LED-lit mirror wall for classes and yoga.' },
    { image: 'assets/gallery/presale-offer.webp', title: 'Presale Offer', caption: 'Special resident discount on annual membership.' },
  ],
  start: 2, height: 'clamp(440px, 46vw, 600px)', cardWidth: 270, sag: 40,
  string: '#b5d636', background: 'transparent', ink: '#ffffff', ariaLabel: 'Gym photos',
});
$('#galPrev')?.addEventListener('click', () => gallery.step(-1));
$('#galNext')?.addEventListener('click', () => gallery.step(1));

// Liquid glass menu (see liquid-nav.js)
const ic = d => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const navItems = [
  { label: 'Home', href: '#home', fx: 'glow', icon: ic('<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6 9.6V20h12V9.6"/><path class="nv-door" d="M10 20v-5h4v5Z"/>') },
  { label: 'About', href: '#about', fx: 'wave', icon: ic('<circle cx="12" cy="8.5" r="3.8"/><path d="M4.8 20c1.2-3.4 4-5 7.2-5s6 1.6 7.2 5"/>') },
  { label: 'Facilities', href: '#facilities', fx: 'pop', icon: ic('<path d="M6 7v10M3 9v6M18 7v10M21 9v6M6 12h12"/>') },
  { label: 'Membership', href: '#membership', fx: 'spin', icon: ic('<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3 10h18M7 15h4"/>') },
  { label: 'Gallery', href: '#gallery', fx: 'drop', icon: ic('<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-9 9"/>') },
  { label: 'Contact', href: '#contact', fx: 'plane', icon: ic('<path d="M21 12.2 3.6 5.4l2.7 6.8-2.7 6.4L21 12.2Zm-14.7 0H13"/>') },
];
let spyLockUntil = 0;
const liquid = window.LiquidNavbar($('#liquidNav'), {
  items: navItems, tone: 'dark',
  onChange: () => { spyLockUntil = performance.now() + 1200; },
});

// Header shade + scroll spy that moves the water drop
const sections = $$('main section[id]');
function onScroll(){
  $('.site-header').classList.toggle('scrolled', window.scrollY > 40);
  if (performance.now() < spyLockUntil) return;
  let current = 'home';
  sections.forEach(sec => { if (sec.getBoundingClientRect().top <= 160) current = sec.id; });
  const i = navItems.findIndex(it => it.href === `#${current}`);
  if (i >= 0) liquid.setActive(i);
}
addEventListener('scroll', onScroll, {passive:true});
onScroll();
$('#year').textContent = new Date().getFullYear();

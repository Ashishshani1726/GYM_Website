/*
 * Polaroid Line Carousel, plain JavaScript version of
 * react-version/components/ui/polaroid-line-carousel.tsx.
 * Instant photos pegged to a sagging string: drag the line, click a print,
 * use the arrows or ←/→, and the prints swing on their pegs.
 *
 * window.PolaroidCarousel(rootEl, { slides, start, height, cardWidth, sag,
 *   swing, autoplay, string, background, ink, onChange, ariaLabel })
 */
(function () {
  const wrap = (i, n) => (n ? ((i % n) + n) % n : 0);
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const stringY = (x, w, y0, sag) => { const t = clamp(x / w, 0, 1); return y0 + 4 * sag * t * (1 - t); };
  function springStep(x, v, target, dt, k = 70) {
    const c = 2 * Math.sqrt(k);
    const nv = v + (k * (target - x) - c * v) * dt;
    return [x + nv * dt, nv];
  }
  function swingStep(a, w, lineVel, dt, gain) {
    const nw = w + (-38 * a - 4.2 * w + lineVel * 0.0034 * gain) * dt;
    return [clamp(a + nw * dt, -0.6, 0.6), nw];
  }
  const nearestAt = (off, spacing, n) => clamp(Math.round(off / spacing), 0, Math.max(0, n - 1));
  const pad2 = n => (n < 10 ? '0' + n : String(n));
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

  const PL_CSS = [
    ".pl-root{position:relative;width:100%;overflow:hidden;background:var(--pl-bg);color:var(--pl-ink);user-select:none;-webkit-user-select:none;touch-action:pan-y;outline:none;cursor:grab}",
    ".pl-root[data-drag='1']{cursor:grabbing}",
    ".pl-root:focus-visible{box-shadow:inset 0 0 0 2px var(--pl-ink)}",
    ".pl-string{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;overflow:visible}",
    ".pl-card{position:absolute;left:0;top:0;width:var(--pl-cw);transform-origin:50% 0;will-change:transform;cursor:inherit}",
    ".pl-print{margin-top:10px;background:#fbfaf7;padding:10px 10px 0;box-shadow:0 1px 2px rgba(0,0,0,.12),0 18px 30px -16px rgba(0,0,0,.4);transition:transform .5s cubic-bezier(.2,.7,.2,1),filter .5s ease}",
    ".pl-card[data-on='0'] .pl-print{transform:scale(.9);filter:saturate(.7) brightness(.96)}",
    ".pl-shot{position:relative;aspect-ratio:1;overflow:hidden;background:#d9d5cc}",
    ".pl-shot img{position:absolute;inset:0;width:100%;height:100%;max-width:none;object-fit:cover;display:block;pointer-events:none}",
    ".pl-note{height:46px;display:flex;align-items:center;justify-content:center;padding:0 6px;font:italic 400 15px/1.1 ui-serif,Georgia,'Times New Roman',serif;color:#3b3833;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".pl-peg{position:absolute;left:50%;top:0;width:10px;height:26px;margin-left:-5px;border-radius:2px;background:linear-gradient(90deg,#c9a67a,#e3c9a1 45%,#b8915f);box-shadow:0 2px 3px rgba(0,0,0,.25)}",
    ".pl-peg::after{content:'';position:absolute;left:4px;top:8px;width:2px;height:7px;background:rgba(80,60,30,.45);border-radius:1px}",
    ".pl-bar{position:absolute;left:clamp(16px,4vw,56px);right:clamp(16px,4vw,56px);bottom:clamp(20px,4vh,40px);display:flex;align-items:center;gap:clamp(12px,2vw,24px);cursor:default}",
    ".pl-cap{flex:1;min-width:0;overflow:hidden;padding-bottom:.15em}",
    ".pl-cap>*{display:block;animation:pl-in .55s cubic-bezier(.2,.8,.2,1) both}",
    ".pl-title{font:500 clamp(18px,2.2vw,26px)/1.15 ui-serif,Georgia,'Times New Roman',serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".pl-sub{margin-top:4px;font:400 13px/1.4 ui-sans-serif,system-ui,sans-serif;color:var(--pl-muted)}",
    ".pl-count{font:500 12px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.14em;color:var(--pl-muted)}",
    ".pl-count b{color:var(--pl-ink);font-weight:500}",
    ".pl-btn{appearance:none;width:40px;height:40px;border-radius:50%;border:1px solid var(--pl-line);background:transparent;color:inherit;display:grid;place-items:center;cursor:pointer;transition:background .2s ease,color .2s ease}",
    ".pl-btn:hover{background:var(--pl-ink);color:var(--pl-bg)}",
    ".pl-btn:focus-visible{outline:2px solid var(--pl-ink);outline-offset:2px}",
    ".pl-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}",
    "@keyframes pl-in{from{transform:translateY(100%);opacity:0}to{transform:none;opacity:1}}",
    "@media (prefers-reduced-motion:reduce){.pl-cap>*{animation:none}.pl-print{transition:none}}",
  ].join("\n");

  window.PolaroidCarousel = function (root, opts = {}) {
    const o = Object.assign({
      slides: [], start: 0, height: '100svh', cardWidth: 300, sag: 46, swing: 1, autoplay: 4500,
      string: '#8a7f72', background: '#efece6', ink: '#161513', onChange: null, ariaLabel: 'Image carousel',
    }, opts);
    const slides = o.slides, n = slides.length;
    if (!root || !n) return null;

    if (!document.getElementById('pl-css')) {
      const st = document.createElement('style'); st.id = 'pl-css'; st.textContent = PL_CSS; document.head.appendChild(st);
    }
    root.classList.add('pl-root');
    Object.assign(root.style, { height: typeof o.height === 'number' ? o.height + 'px' : o.height });
    root.style.setProperty('--pl-bg', o.background);
    root.style.setProperty('--pl-ink', o.ink);
    root.style.setProperty('--pl-muted', 'color-mix(in srgb, var(--pl-ink) 55%, transparent)');
    root.style.setProperty('--pl-line', 'color-mix(in srgb, var(--pl-ink) 18%, transparent)');
    root.dataset.drag = '0';
    root.setAttribute('role', 'region');
    root.setAttribute('aria-roledescription', 'carousel');
    root.setAttribute('aria-label', o.ariaLabel);
    root.tabIndex = 0;

    const chev = d => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="${d}" stroke="currentColor" stroke-width="1.4"/></svg>`;
    root.innerHTML =
      `<svg class="pl-string" aria-hidden="true"><path fill="none" stroke="${esc(o.string)}" stroke-width="1.5" stroke-linecap="round"/></svg>` +
      slides.map((s, i) => `<div class="pl-card" data-i="${i}" data-on="0"><div class="pl-print"><div class="pl-shot">${s.image ? `<img src="${esc(s.image)}" alt="${esc(s.alt || s.title)}" draggable="false">` : ''}</div><div class="pl-note">${esc(s.title)}</div></div><div class="pl-peg"></div></div>`).join('') +
      `<div class="pl-bar"><div class="pl-cap" aria-hidden="true"></div><span class="pl-count" aria-hidden="true"></span>` +
      `<button type="button" class="pl-btn" aria-label="Previous">${chev('M10 3 5 8l5 5')}</button>` +
      `<button type="button" class="pl-btn" aria-label="Next">${chev('m6 3 5 5-5 5')}</button></div>` +
      `<div class="pl-sr" aria-live="polite"></div>`;

    const path = root.querySelector('.pl-string path');
    const cards = [...root.querySelectorAll('.pl-card')];
    const cap = root.querySelector('.pl-cap'), count = root.querySelector('.pl-count'), sr = root.querySelector('.pl-sr');
    const [prevBtn, nextBtn] = root.querySelectorAll('.pl-btn');

    const S = { off: 0, vel: 0, target: 0, a: [], w: [] };
    let size = { w: 1200, h: 800, cw: o.cardWidth };
    let spacing = size.cw * 1.08;
    let active = -1, drag = null, lastTouch = 0;

    function setActive(i) {
      active = i;
      cards.forEach((c, k) => { c.dataset.on = k === i ? '1' : '0'; if (k === i) c.removeAttribute('aria-hidden'); else c.setAttribute('aria-hidden', 'true'); });
      const s = slides[i] || {};
      cap.innerHTML = (s.title ? `<span class="pl-title">${esc(s.title)}</span>` : '') + (s.caption ? `<span class="pl-sub">${esc(s.caption)}</span>` : '');
      count.innerHTML = `<b>${pad2(i + 1)}</b> / ${pad2(n)}`;
      sr.textContent = 'Print ' + (i + 1) + ' of ' + n + (s.title ? ': ' + s.title : '');
      o.onChange && o.onChange(i);
    }
    const goTo = i => { S.target = clamp(i, 0, n - 1) * spacing; };

    function measure() {
      const r = root.getBoundingClientRect();
      const cw = Math.round(Math.max(150, Math.min(o.cardWidth, r.width * 0.42, r.height * 0.42)));
      const idx = Math.max(0, active);
      size = { w: r.width, h: r.height, cw };
      spacing = cw * 1.08;
      root.style.setProperty('--pl-cw', cw + 'px');
      S.target = S.off = idx * spacing;
    }

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let visible = true, raf = 0, prev = performance.now();
    function frame(now) {
      raf = 0;
      if (!visible) return;
      const dt = Math.min(0.033, (now - prev) / 1000);
      prev = now;
      const { w, h, cw } = size;
      const y0 = Math.max(40, h * 0.2);
      let lineVel;
      if (drag && drag.moved) lineVel = drag.v * 1000;
      else {
        const before = S.off;
        [S.off, S.vel] = springStep(S.off, S.vel, S.target, dt);
        lineVel = -(S.off - before) / Math.max(dt, 1e-3);
      }
      const g = reduce ? 0 : o.swing;
      const near = nearestAt(S.off, spacing, n);
      for (let i = 0; i < n; i++) {
        const el = cards[i];
        const x = w / 2 + i * spacing - S.off;
        if (x < -cw * 1.5 || x > w + cw * 1.5) { el.style.visibility = 'hidden'; continue; }
        el.style.visibility = 'visible';
        let a = S.a[i] || 0, av = S.w[i] || 0;
        [a, av] = swingStep(a, av, lineVel, dt, g);
        if (g) a += Math.sin(now / 1300 + i * 1.7) * 0.0009 * g;
        S.a[i] = a; S.w[i] = av;
        const y = stringY(x, w, y0, o.sag) - 6;
        el.style.transform = 'translate(' + (x - cw / 2).toFixed(1) + 'px,' + y.toFixed(1) + 'px) rotate(' + a.toFixed(4) + 'rad)';
        el.style.zIndex = String(i === near ? n + 1 : n - Math.abs(i - near));
      }
      path.setAttribute('d', 'M0 ' + y0 + ' Q' + w / 2 + ' ' + (y0 + 2 * o.sag) + ' ' + w + ' ' + y0);
      if (near !== active) setActive(near);
      raf = requestAnimationFrame(frame);
    }

    // start on the chosen print
    setActive(clamp(o.start | 0, 0, n - 1));
    measure();
    new ResizeObserver(measure).observe(root);
    new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      if (visible && !raf) { prev = performance.now(); raf = requestAnimationFrame(frame); }
    }).observe(root);
    raf = requestAnimationFrame(frame);

    if (o.autoplay && n > 1) {
      setInterval(() => {
        if (document.hidden || drag || performance.now() - lastTouch < o.autoplay) return;
        goTo(active >= n - 1 ? 0 : active + 1);
      }, o.autoplay);
    }

    root.addEventListener('pointerdown', e => {
      if (e.target.closest('.pl-bar')) return;
      lastTouch = performance.now();
      drag = { x: e.clientX, off: S.off, lx: e.clientX, lt: e.timeStamp, v: 0, moved: false };
    });
    root.addEventListener('pointermove', e => {
      const d = drag;
      if (!d) return;
      const dx = e.clientX - d.x;
      if (!d.moved && Math.abs(dx) > 5) { d.moved = true; root.dataset.drag = '1'; root.setPointerCapture(e.pointerId); }
      if (!d.moved) return;
      const dt = Math.max(1, e.timeStamp - d.lt);
      d.v = 0.7 * ((e.clientX - d.lx) / dt) + 0.3 * d.v;
      d.lx = e.clientX; d.lt = e.timeStamp;
      const max = (n - 1) * spacing;
      let off = d.off - dx;
      if (off < 0) off *= 0.35;
      if (off > max) off = max + (off - max) * 0.35;
      S.off = off;
    });
    const onUp = e => {
      const d = drag;
      drag = null;
      lastTouch = performance.now();
      if (!d) return;
      if (d.moved) {
        root.dataset.drag = '0';
        S.vel = -d.v * 1000;
        goTo(nearestAt(S.off - d.v * 180, spacing, n));
        return;
      }
      const card = e.target.closest('[data-i]');
      if (card) goTo(Number(card.getAttribute('data-i')));
    };
    root.addEventListener('pointerup', onUp);
    root.addEventListener('pointercancel', onUp);

    const step = dir => { lastTouch = performance.now(); goTo(clamp(active + dir, 0, n - 1)); };
    prevBtn.addEventListener('click', () => step(-1));
    nextBtn.addEventListener('click', () => step(1));
    root.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight') step(1);
      else if (e.key === 'ArrowLeft') step(-1);
      else return;
      e.preventDefault();
    });

    return { goTo, step, get active() { return active; } };
  };
})();

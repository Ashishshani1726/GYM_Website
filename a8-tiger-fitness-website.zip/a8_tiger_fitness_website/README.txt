A8 TIGER FITNESS WEBSITE

How to run:
1. Extract the ZIP.
2. Double-click index.html, OR place the folder inside XAMPP htdocs.
3. All gym photos are stored locally in the assets folder.

Included:
- Responsive desktop/mobile layout
- 3D hover tilt effects
- Scroll reveal + parallax animation
- Gallery with real gym photos
- Facilities, membership offer and contact sections
- Call, WhatsApp and Google Maps buttons

Contact information used:
9152510140 / 7208426300
A Wing, Krishna Regency, near Pathak College, Datta Mandir Road, Vakola, Santacruz (E), Mumbai
